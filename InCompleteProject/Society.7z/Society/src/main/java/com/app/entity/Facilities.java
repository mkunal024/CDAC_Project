package com.app.entity;

public enum Facilities {
MEETINGHALL,PARTYHALL;
}
