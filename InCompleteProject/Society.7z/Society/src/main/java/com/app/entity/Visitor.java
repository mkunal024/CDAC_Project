package com.app.entity;

//import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="Visitor")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Visitor extends BaseEntity{
	@Column(name="name", length=20)
	private String name;
	@Column(name="Purpose", length=50)
	private String Purpose;
	@Column(name="Block", length=1)
	private String block;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="Houseno")
	private User houseNo;
	@Column(name="DateOfVisit")
	//private LocalDate date;
	//@Column(name="CheckInTime")
	private LocalDateTime checkin;
}
