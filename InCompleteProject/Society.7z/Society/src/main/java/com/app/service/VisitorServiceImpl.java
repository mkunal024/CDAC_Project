package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entity.Visitor;
import com.app.repository.VisitorRepository;

@Service
@Transactional
public class VisitorServiceImpl implements VisitorService {

	@Autowired
	private VisitorRepository vRepo;
	
	@Override
	public Visitor addVisitorDetails(Visitor v) {
		return vRepo.save(v);
	}

	@Override
	public List<Visitor> getVisitorDetails() {
		return vRepo.findAll();
	}

	@Override
	public Visitor updateVisitorDetails(Visitor v) {
		return vRepo.save(v);
	}

	@Override
	public String deleteVisitorDetails(Long vid) {
		String msg="Invalid id, Visitor details not deleted";
		if(vRepo.existsById(vid))
		{
			vRepo.deleteById(vid);
			msg="Visitor with id "+vid+" deleted!!";
		}

		return msg;
	}

}
