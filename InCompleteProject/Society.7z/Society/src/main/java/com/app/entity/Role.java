package com.app.entity;

public enum Role {
ADMIN,OWNER,SECURITYGUARD;
}
