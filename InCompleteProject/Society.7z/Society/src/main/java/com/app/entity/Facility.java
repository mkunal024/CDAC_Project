package com.app.entity;



import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="Facility")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Facility extends BaseEntity{
	
	@Column(name="FacilityCodeNo")
	private Facilities code;
	@Column(name="Status")
	private Availability available;
	@Column(name="BookingDate")
	private LocalDate BookingDate;
	@Column(name="BookedDate")
	private LocalDate BookedDate;
}
