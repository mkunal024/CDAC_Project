package com.app.service;

import java.util.List;

import com.app.entity.Visitor;

public interface VisitorService {

	Visitor addVisitorDetails(Visitor v);

	List<Visitor> getVisitorDetails();

	Visitor updateVisitorDetails(Visitor v);

	String deleteVisitorDetails(Long id);
}
