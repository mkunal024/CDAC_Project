package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.entity.Booking;
import com.app.repository.BookingRepository;

@Service
@Transactional
public class BookingServiceImpl implements BookingService{

	@Autowired
	private BookingRepository bRepo;
	
	@Override
	public Booking addBooking(Booking b) {
		
		return bRepo.save(b);
	}

	@Override
	public List<Booking> getBooking() {
		
		return bRepo.findAll();
	}

	@Override
	public Booking updateBooking(Booking b) {
		
		return bRepo.save(b);
	}

	@Override
	public String deleteBooking(Long eid) {
		
		String msg="Invalid id, Booking details not deleted";
		if(bRepo.existsById(eid))
		{
			bRepo.deleteById(eid);
			msg="Booking with id "+eid+" deleted!!";
		}

		return msg;
	}

	
}
