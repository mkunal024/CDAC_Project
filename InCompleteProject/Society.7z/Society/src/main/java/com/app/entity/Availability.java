package com.app.entity;

public enum Availability {
	NOTAAVAILABLE,AVAILABLE;
}
