package com.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="User")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString(exclude="password")
public class User {
	@Id
	@Column(name="HouseNo")
	private Long houseNo;
	@Column(name="name", length=20)
	private String name;
	@Column(name="Block", length=1)
	private String Block;
	@Column(name="email", length=40,unique=true)
	private String email;
	@Column(name="password", length=20,nullable=false)
	private String password;
	@Column(name="Role", length=10)
	private Role role;
}
